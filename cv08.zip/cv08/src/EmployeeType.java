
public enum EmployeeType {
	ACTIVE, INACTIVE, DELETED
}
