
public interface Animal {
	public void sound();
}
