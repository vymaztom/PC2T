
public abstract class AbstractAnimal {
	protected byte age;  
	public abstract void sound();
}
