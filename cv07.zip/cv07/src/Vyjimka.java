public class Vyjimka extends Exception {
	public Vyjimka(String a) {
		super(a);
	}
}
